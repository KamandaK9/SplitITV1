//
//  SplitITApp.swift
//  SplitIT
//
//  Created by Daniel Senga on 2023/02/27.
//

import SwiftUI

@main
struct SplitITApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
